﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


namespace ProyectoFinalIngeSoftware
{
    public partial class Pedidos : System.Web.UI.Page
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=(local)\sqle2019;initial Catalog=Pedido;Integrated Security=True;");


        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["username"] == null)
                Response.Redirect("InicioSesión.aspx");
        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            
                sqlCon.Open();
                int Cod_Producto = Convert.ToInt32(txtCodP.Text);
                string Nom_Producto = txtNomP.Text;
                int Cantidad = Convert.ToInt32(txtCant.Text);
                String Zona = txtZona.Text;

                SqlCommand cmd = new SqlCommand("INSERT INTO Pedido(Nro_Pedido, Cod_Producto, Nom_Producto, Cantidad,Zona) VALUES (default, " + Cod_Producto + "," + Nom_Producto + "," + Cantidad + ","+Zona+")");
                cmd.ExecuteNonQuery();
            
        }

        protected void BtnLogOut_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("InicioSesión.aspx");
        }
    }
}