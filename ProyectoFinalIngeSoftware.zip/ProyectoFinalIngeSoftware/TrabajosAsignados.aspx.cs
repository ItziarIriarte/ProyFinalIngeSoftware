﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace ProyectoFinalIngeSoftware
{
    public partial class TrabajosAsignados : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

      
        protected void BtnAsignar_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=(local)\sqle2019;initial Catalog=TrabajosAsignado;Integrated
                Security=True;"))
            {
                sqlCon.Open();
                int Cod_Distribuidor = Convert.ToInt32(TextBox1.Text);
                int Nro_Pedido = Convert.ToInt32(TextBox2.Text);

                SqlCommand cmd = new SqlCommand("INSERT INTO TrabajosAsignado(Nro_TareaAsignada, Nro_Pedido, Cod_Distribuidor) VALUES (default, " + Cod_Distribuidor + "," + Nro_Pedido + ")");
                cmd.ExecuteNonQuery();
               
            }
        }
    }
}